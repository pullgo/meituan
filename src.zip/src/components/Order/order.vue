<template>
  <div class="order">订单
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    // props: {
    // },
    // data() {
    // },
    // created() {
    // },
    // methods: {
    // },
    // components: {
    // },
  };
</script>

<style lang="stylus" rel="stylesheet/stylus">
  .order
    color: #ccc
</style> 