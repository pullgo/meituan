<template>
  <div class="me">我
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    // props: {
    // },
    // data() {
    // },
    // created() {
    // },
    // methods: {
    // },
    // components: {
    // },
  };
</script>

<style lang="stylus" rel="stylesheet/stylus">
</style> 