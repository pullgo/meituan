<template>
  <div class="zheader">
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    // props: {
    // },
    // data() {
    // },
    // created() {
    // },
    // methods: {
    // },
    // components: {
    // },
  };
</script>

<style lang="stylus" rel="stylesheet/stylus">
</style> 