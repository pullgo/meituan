<template>
  <div class="Massage">
    <!--messages打开页面-->
    <transition class="hide">
      <div class="messages-wrapper">
        <div class="messages-header">
          <span class="iconfont return icon-fanhui"></span>
          <span class="title">消息中心</span>
        </div>
        <div class="messages-content">
          <ul>
            <li v-for="mess in messages" class="mess">
              <img class="img" :src="mess.image" width="60" height="60">
              <span class="text">{{mess.title}}</span>
            </li>
          </ul>
        </div>
      </div>
    </transition>
    <router-view></router-view>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    created() {
      axios.get('../data.json').then((res) => {
        this.massages = res.data.massages
        console.log(this.massages)
      })
    },
  }
</script>

<style lang="stylus" rel="stylesheet/stylus">
  .messages-wrapper
    width: 100%
    //height: 768px
    background: #f6f6f6
    position: absolute
    top: 0px
    left: 0px
    //z-index: -1
    //padding-bottom: 55%
    .hide-enter-active, .hide-leave-active
      transition: opacity 10s
    .hide-enter, .hide-leave-to       
      opacity: 0
    /*&.hide-enter-active 
      transition: all .3s ease
    &.hide-leave-active 
      transition: all .8s cubic-bezier(1.0, 0.5, 0.8, 1.0)
    &.hide-enter, .hide-leave-to
      transform: translateX(10px)
      opacity: 0*/
    .messages-header
      background: #f6f6f6
      border-bottom: 1px solid #ededed
      height: 48px
      width: 100%
      box-sizing: border-box
      .return
        float: left
        text-align: left
        margin-left: 14px
        margin-top: 10px
        color: #727272
        font-size: 25px
        padding: 6px
      .title
        display: flex
        font-size: 20px
        color: #3c3c3c
        //align-items: center
        justify-content: center
        line-height: 48px
    .messages-content
      background: #ffffff
      text-align: left
      padding-left: 20px
      .mess
        height: 80px
        width: 100%
        border-bottom: 1px solid #ededed
        box-sizing: border-box
        .img
          margin-top: 11px
          margin-bottom: 11px
          vertical-align: middle
        .text
          margin-left: 18px
          color: #050505

</style> 